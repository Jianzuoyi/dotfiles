cite 'about-alias'
about-alias 'Atom.io editor abbreviations'

alias a='atom'
alias ah='atom .'
alias apmup='apm update --no-confirm'
alias apmi='apm install'
