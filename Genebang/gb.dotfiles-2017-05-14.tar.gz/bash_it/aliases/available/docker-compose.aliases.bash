cite 'about-alias'
about-alias 'docker-compose abbreviations'

alias dco="docker-compose"
alias dcofresh="docker-compose-fresh"
alias dcol="docker-compose logs -f --tail 100"
