
. <(ng completion --bash)

