cite about-plugin
about-plugin 'load hub, if you are using it'

command -v hub &> /dev/null && eval "$(hub alias -s)"
